import React from 'react';
import {StyleSheet, Text, View} from 'react-native';

const Upload = () => {
  return (
    <View>
      <Text>Upload</Text>
    </View>
  );
};

export default Upload;

const styles = StyleSheet.create({});
