import React from 'react';
import {StyleSheet, Text, View} from 'react-native';
import Background from '../../component/basic/Background';

const Info = () => {
  return (
    <Background>
      <Text>Info</Text>
    </Background>
  );
};

export default Info;

const styles = StyleSheet.create({});
